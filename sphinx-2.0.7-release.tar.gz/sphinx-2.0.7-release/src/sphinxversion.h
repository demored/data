#define SPH_SVN_TAG "release"
#define SPH_SVN_REV 3759
#define SPH_SVN_REVSTR "3759"
#define SPH_SVN_TAGREV "r3759"
#define SPHINX_TAG "-release"
